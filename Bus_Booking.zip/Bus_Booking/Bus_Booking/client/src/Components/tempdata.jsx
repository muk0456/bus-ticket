import background2 from "../Assets/Images/busbooking.jpg";
import background1 from "../Assets/Images/bookbus.png";
var items = [
    {
      heading: "Welcome to",
      img:background2
    },
    {
      heading: "Welcome to",
      img:background1,
    },
    {
      heading: "Welcome to",
      img:
        "https://images.pexels.com/photos/877971/pexels-photo-877971.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=1000",
    },
  ];
  export default items;